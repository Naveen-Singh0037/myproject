# Fixed Navbar Scroll Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/wesleymenezes/pen/LgpNyv](https://codepen.io/wesleymenezes/pen/LgpNyv).

